<script type="text/html" id="tmpl-boldgrid-editor-drag-handle">
	<div class="bg-drag-popover section-drag-handle">
		<span class="popover-imhwpb section-popover-imhwpb bottom-popover-imhwpb ">
			<div title="Move" contenteditable="false" draggable="true" class="no-select-imhwpb drag-handle-imhwpb draggable-button">
	 			<span class="genericon genericon-move" aria-hidden="true"></span>
			</div>
			<div title="Drag Sections" contenteditable="false" class="move-sections no-select-imhwpb draggable-button">
	 			<span class="genericon genericon-unzoom" aria-hidden="true"></span>
			</div>
			<div class="popover-menu-imhwpb hidden">
				<ul>
					<li class="no-select-imhwpb action-list" data-action="">Edit Section</li>
					<li class="no-select-imhwpb action-list" data-action="duplicate">Clone</li>
					<li class="no-select-imhwpb action-list" data-action="delete">Delete</li>
					<li class="no-select-imhwpb action-list" data-action="section-width">Section Width</li>
					<li class="no-select-imhwpb action-list" data-action="move-up">Move Up</li>
					<li class="no-select-imhwpb action-list" data-action="move-down">Move Down</li>
					<li class="no-select-imhwpb action-list" data-action="add-new">Add Empty Section</li>
					<li class="no-select-imhwpb action-list" data-action="background">Change Background</li>
				</ul>
			</div>
			<div title="Edit Section" class="context-menu-imhwpb draggable-button">
				<span class="genericon genericon-menu" aria-hidden="true"></span>
			</div>
		</span>
	</div>
</script>

